<template>
    <div class="box">
        <Container position="a导航"></Container>
    </div>
</template>

<script>
import Container from '@/components/pinglun/ContainerBox.vue'
export default {
    name:"box",
    data(){
        return {

        }
    },
    methods:{

    },
    mounted(){
        
    },
    components:{
        Container,
    },
   
}
</script>

<style lang="">
    
</style>